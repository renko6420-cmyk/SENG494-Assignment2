# SENG 494 — Assignment 2: Laravel Course Catalog

A small Laravel course catalog. Visitors can browse courses and open a course details page showing its instructor.

## Requirements

- PHP 8.2 or later
- Composer
- A database supported by Laravel (SQLite or MySQL)

## Create the Laravel project

Run these commands in a terminal:

```bash
composer create-project laravel/laravel course-catalog
cd course-catalog
```

Copy the `app`, `database`, `resources`, and `routes` folders from this assignment package into the new `course-catalog` folder. Merge the folders and replace matching files when prompted. Keep the other Laravel framework files created by Composer.

## Create the controller with Artisan

From the Laravel project folder, run:

```bash
php artisan make:controller CourseController
```

Then use the provided `app/Http/Controllers/CourseController.php` code from this package.

## Configure and run

```bash
cp .env.example .env
php artisan key:generate
```

Configure the database in `.env`.

For SQLite, create an empty `database/database.sqlite` file and set:

```env
DB_CONNECTION=sqlite
```

For MySQL, set `DB_CONNECTION`, `DB_HOST`, `DB_PORT`, `DB_DATABASE`, `DB_USERNAME`, and `DB_PASSWORD` to your local database values.

Run the migrations and seed data:

```bash
php artisan migrate --seed
php artisan serve
```

Open `http://127.0.0.1:8000/courses`.

## Routes

- `GET /courses` — displays all courses.
- `GET /courses/{id}` — displays one course and its instructor.

## Included features

- `CourseController` created using the Laravel Artisan command above.
- Reusable Blade layout (`layouts/app.blade.php`) and `x-course-card` component.
- Blade `@foreach` and `@if` directives.
- Instructor and Course migrations with a foreign key.
- `Instructor::courses()` hasMany and `Course::instructor()` belongsTo relationships.
- Seeder creates 3 instructors and 10 courses.

## Laravel request lifecycle

When a user visits a page, the request first enters Laravel through the public entry point. Laravel loads the application and passes the request through the middleware. The router checks the URL and sends it to the matching controller action. The controller gets the required data from the models and database, then returns a view. Blade builds the HTML page, and Laravel sends the response back to the user's browser.

## Git submission

Initialize the repository and make regular commits as you work:

```bash
git init
git add .
git commit -m "Add Laravel course catalog structure"
git add .
git commit -m "Add course routes and controller"
git add .
git commit -m "Add Blade views and reusable component"
git add .
git commit -m "Add migrations, relationships, seeder, and README"
```

To submit a repository link, create an empty repository on GitHub, then connect and push your local repository:

```bash
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Replace `YOUR_GITHUB_REPOSITORY_URL` with the URL shown by GitHub. Do not submit a made-up link.

## Security and AI-use statement

The `.env` file is excluded through `.gitignore`; do not commit passwords, API keys, or other secrets. The `.env.example` file contains only example configuration.

AI-use statement: ChatGPT was used to help prepare the initial project structure, example code, and README. Review, run, test, and understand the project before submission, and update this statement so it accurately describes your own use.
