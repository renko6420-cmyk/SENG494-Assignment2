<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Course extends Model
{
    use HasFactory;

    protected $fillable = ['title', 'code', 'description', 'instructor_id'];

    public function instructor(): BelongsTo
    {
        return $this->belongsTo(Instructor::class);
    }
}
