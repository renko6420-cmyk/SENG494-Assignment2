@extends('layouts.app')

@section('title', $course->title)

@section('content')
    <div class="card">
        <h1>{{ $course->title }}</h1>
        <p class="muted">Course code: {{ $course->code }}</p>
        <p>{{ $course->description ?? 'No description available.' }}</p>
        <p><strong>Instructor:</strong> {{ $course->instructor->name }}</p>
        <p><strong>Instructor email:</strong> {{ $course->instructor->email }}</p>
        <a class="button" href="{{ route('courses.index') }}">Back to courses</a>
    </div>
@endsection
