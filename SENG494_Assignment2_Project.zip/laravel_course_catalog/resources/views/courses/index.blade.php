@extends('layouts.app')

@section('title', 'All Courses')

@section('content')
    <h1>Available Courses</h1>

    @if ($courses->isEmpty())
        <div class="card">No courses are available at the moment.</div>
    @else
        @foreach ($courses as $course)
            <x-course-card :course="$course" />
        @endforeach
    @endif
@endsection
