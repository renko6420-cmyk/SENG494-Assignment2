<div class="card">
    <h2>{{ $course->title }}</h2>
    <p class="muted">Course code: {{ $course->code }}</p>
    <p>Instructor: {{ $course->instructor->name }}</p>
    <a class="button" href="{{ route('courses.show', $course->id) }}">View details</a>
</div>
