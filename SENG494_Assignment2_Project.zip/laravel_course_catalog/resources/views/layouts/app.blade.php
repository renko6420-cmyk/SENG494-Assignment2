<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Course Catalog')</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f4f6f8; color: #222; }
        header { background: #243b53; color: white; padding: 20px 8%; }
        header a { color: white; text-decoration: none; font-weight: bold; }
        main { max-width: 950px; margin: 32px auto; padding: 0 20px; }
        .card { background: white; padding: 20px; margin-bottom: 16px; border-radius: 8px; box-shadow: 0 2px 8px #00000010; }
        .button { display: inline-block; background: #2874a6; color: white; padding: 9px 14px; border-radius: 5px; text-decoration: none; }
        .muted { color: #64748b; }
    </style>
</head>
<body>
    <header><a href="{{ route('courses.index') }}">Course Catalog</a></header>
    <main>
        @yield('content')
    </main>
</body>
</html>
