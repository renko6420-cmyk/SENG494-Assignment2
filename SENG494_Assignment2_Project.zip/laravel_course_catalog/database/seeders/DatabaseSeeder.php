<?php

namespace Database\Seeders;

use App\Models\Course;
use App\Models\Instructor;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $instructors = [
            ['name' => 'Sara Ahmed', 'email' => 'sara@example.com'],
            ['name' => 'Khalid Ali', 'email' => 'khalid@example.com'],
            ['name' => 'Nora Saleh', 'email' => 'nora@example.com'],
        ];

        $createdInstructors = [];
        foreach ($instructors as $data) {
            $createdInstructors[$data['email']] = Instructor::create($data);
        }

        $courses = [
            ['title' => 'Introduction to Programming', 'code' => 'CS101', 'description' => 'Programming fundamentals and problem solving.', 'instructor_email' => 'sara@example.com'],
            ['title' => 'Database Systems', 'code' => 'CS202', 'description' => 'Database concepts, SQL, and data modeling.', 'instructor_email' => 'khalid@example.com'],
            ['title' => 'Web Development', 'code' => 'CS203', 'description' => 'Building dynamic websites and web applications.', 'instructor_email' => 'nora@example.com'],
            ['title' => 'Computer Networks', 'code' => 'CS204', 'description' => 'Network models, protocols, and communication.', 'instructor_email' => 'sara@example.com'],
            ['title' => 'Software Engineering', 'code' => 'CS205', 'description' => 'Software processes, requirements, and design.', 'instructor_email' => 'khalid@example.com'],
            ['title' => 'Artificial Intelligence', 'code' => 'CS301', 'description' => 'An introduction to intelligent systems.', 'instructor_email' => 'nora@example.com'],
            ['title' => 'Information Security', 'code' => 'CS302', 'description' => 'Core principles of information security.', 'instructor_email' => 'sara@example.com'],
            ['title' => 'Operating Systems', 'code' => 'CS303', 'description' => 'Processes, memory, and file systems.', 'instructor_email' => 'khalid@example.com'],
            ['title' => 'Mobile Application Development', 'code' => 'CS304', 'description' => 'Design and development of mobile apps.', 'instructor_email' => 'nora@example.com'],
            ['title' => 'Cloud Computing', 'code' => 'CS305', 'description' => 'Cloud services, deployment, and architecture.', 'instructor_email' => 'sara@example.com'],
        ];

        foreach ($courses as $data) {
            $instructorEmail = $data['instructor_email'];
            unset($data['instructor_email']);

            $data['instructor_id'] = $createdInstructors[$instructorEmail]->id;
            Course::create($data);
        }
    }
}
